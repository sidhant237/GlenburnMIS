from App import app

app.run(debug = True)