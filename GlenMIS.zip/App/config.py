import os

#creating base directory
basedir = os.path.abspath(os.path.dirname(__file__))


#cross origin response certificate configuration
CORS_HEADERS = 'Content-Type'

#SQL DB configuratiosn
MYSQL_HOST = "localhost"
MYSQL_USER = "root"
MYSQL_PASSWORD = 'Supernova723!'
MYSQL_DB = "GlenDB"


#mail sending configuration
MAIL_SERVER ='smtp.gmail.com'
MAIL_PORT = 465
MAIL_USERNAME = ''
MAIL_PASSWORD = ''
MAIL_USE_TLS = False
MAIL_USE_SSL = True

